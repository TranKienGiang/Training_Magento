<?php

namespace AHT\Route\Plugin\Controller\Training\Post;

class PostPlugin1
{
//    public function beforeSumNumber(\AHT\Route\Controller\Training\Post\Post $subject, $a, $b)
//    {
//        echo"a before: $a";
//        echo '</br>';
//        echo"a before: $b";
//        echo '</br>';
//        $a = $a +12;
//        $b = $b +12;
//        return[$a,$b];
//    }

//    public function afterSumNumber(\AHT\Route\Controller\Training\Post\Post $subject, $result)
//    {
//        echo '</br>';
//        $result = $result + 16;
//        echo 'result after 1 :' . $result;
//        die();
//    }

//    public function aroundSumNumber(\AHT\Route\Controller\Training\Post\Post $subject, callable  $proceed, $a, $b)
//    {
//        echo '</br>';
//        echo 'a around :' . $a;
//        echo '</br>';
//        echo 'b around :' . $b;
//        $result1 = $proceed($a, $b);
//        echo 'result1 :' . $result1;
////        return $result1;
//    }
}
